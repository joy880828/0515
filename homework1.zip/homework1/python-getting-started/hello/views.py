from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
	
	return HttpResponse("HelloWorld(MySite)")

def db(request):
	greeting = Greeting()
	greeting.save()
	greetings = Greeting.object.all()
	return render(request, "db.html",{"greetings":greetings})